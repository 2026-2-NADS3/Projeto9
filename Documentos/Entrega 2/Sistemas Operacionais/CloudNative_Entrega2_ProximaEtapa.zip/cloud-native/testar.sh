#!/bin/bash
# Teste rápido do ambiente depois do "docker compose up -d --build".
# Uso (Linux, macOS ou Git Bash no Windows):  ./testar.sh [porta]
PORTA="${1:-8080}"
URL="http://localhost:$PORTA"
FALHAS=0

checar() {
    local nome="$1" caminho="$2" esperado="$3"
    local resposta
    resposta=$(curl -s --max-time 10 "$URL$caminho")
    if echo "$resposta" | grep -q "$esperado"; then
        echo "  [OK]    $nome"
    else
        echo "  [FALHA] $nome -> $URL$caminho"
        FALHAS=$((FALHAS + 1))
    fi
}

echo "Containers:"
docker compose ps --format "  {{.Service}}: {{.Status}}"
echo
echo "Testando $URL"
checar "Nginx respondendo"            "/saude"                                "ok"
checar "API conectada ao banco"       "/proxima_etapa_api/status.php"         '"status":"ok"'
checar "Lista de cursos"              "/proxima_etapa_api/cursos.php"         "titulo"
checar "Agenda da aluna 1"            "/proxima_etapa_api/agenda.php?alunoId=1" "codigoQr"
echo
echo "Backups na pasta ./backups:"
ls -1 backups/*.sql.gz 2>/dev/null | sed 's/^/  /' || echo "  nenhum ainda"
echo
[ "$FALHAS" -eq 0 ] && echo "Tudo certo." || echo "$FALHAS teste(s) falharam. Veja: docker compose logs"
exit "$FALHAS"
