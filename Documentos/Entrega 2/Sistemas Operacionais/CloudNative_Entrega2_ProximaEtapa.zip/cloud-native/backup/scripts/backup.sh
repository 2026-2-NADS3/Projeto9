#!/bin/bash
# =============================================================================
# backup.sh - Backup automático do banco do app Próxima Etapa
#
# Roda dentro do container "backup". Gera um dump do MariaDB, compacta com
# gzip, confere se o arquivo não está corrompido, guarda só os N backups mais
# recentes e registra tudo em log com data e hora.
#
# Uso:
#   backup.sh [-k quantidade] [-d pasta_destino] [-h]
#     -k  quantos backups manter (padrão: $BACKUP_MANTER ou 7)
#     -d  pasta onde salvar (padrão: /backups)
#     -h  mostra esta ajuda
#
# Variáveis de ambiente (vêm do docker-compose / arquivo .env):
#   DB_HOST, DB_NAME, DB_ROOT_PASSWORD
# =============================================================================

set -o pipefail

# Quando roda pelo cron, as variáveis do container não chegam sozinhas
[ -f /app/ambiente.sh ] && . /app/ambiente.sh

MANTER="${BACKUP_MANTER:-7}"
DESTINO="/backups"
LOG_DIR="$DESTINO/logs"

mostrar_ajuda() {
    sed -n '3,18p' "$0" | sed 's/^# \{0,1\}//'
}

log() {
    local nivel="$1"; shift
    local linha
    linha="[$(date '+%Y-%m-%d %H:%M:%S')] [$nivel] $*"
    echo "$linha"
    echo "$linha" >> "$LOG_DIR/backup.log"
}

# ---------- parâmetros ----------
while getopts ":k:d:h" opcao; do
    case "$opcao" in
        k) MANTER="$OPTARG" ;;
        d) DESTINO="$OPTARG"; LOG_DIR="$DESTINO/logs" ;;
        h) mostrar_ajuda; exit 0 ;;
        :) echo "Erro: a opção -$OPTARG precisa de um valor." >&2; exit 2 ;;
        \?) echo "Erro: opção inválida -$OPTARG (use -h para ajuda)." >&2; exit 2 ;;
    esac
done

if ! [[ "$MANTER" =~ ^[0-9]+$ ]] || [ "$MANTER" -lt 1 ]; then
    echo "Erro: -k precisa ser um número inteiro maior que zero (recebido: '$MANTER')." >&2
    exit 2
fi

mkdir -p "$LOG_DIR" || { echo "Erro: não foi possível criar $LOG_DIR" >&2; exit 3; }

for variavel in DB_HOST DB_NAME DB_ROOT_PASSWORD; do
    if [ -z "${!variavel}" ]; then
        log ERRO "Variável $variavel não definida. Confira o arquivo .env."
        exit 3
    fi
done

# A senha vai por variável de ambiente, e não na linha de comando, para não aparecer no 'ps'
export MYSQL_PWD="$DB_ROOT_PASSWORD"
DUMP=$(command -v mariadb-dump || command -v mysqldump)
ADMIN=$(command -v mariadb-admin || command -v mysqladmin)

log INFO "Iniciando backup do banco '$DB_NAME' em '$DB_HOST' (mantendo $MANTER cópias)"

# ---------- 1. o banco está respondendo? ----------
tentativa=1
until "$ADMIN" --host="$DB_HOST" --user=root ping --silent > /dev/null 2>&1; do
    if [ "$tentativa" -ge 5 ]; then
        log ERRO "Banco '$DB_HOST' não respondeu depois de 5 tentativas. Backup cancelado."
        exit 4
    fi
    log AVISO "Banco ainda não respondeu (tentativa $tentativa de 5). Nova tentativa em 5s."
    tentativa=$((tentativa + 1))
    sleep 5
done

# ---------- 2. dump compactado ----------
ARQUIVO="$DESTINO/${DB_NAME}_$(date '+%Y%m%d_%H%M%S').sql.gz"

if ! "$DUMP" --host="$DB_HOST" --user=root \
        --single-transaction --routines --triggers --no-tablespaces \
        --databases "$DB_NAME" 2>> "$LOG_DIR/backup.log" | gzip -9 > "$ARQUIVO"; then
    log ERRO "Falha ao gerar o dump. Arquivo incompleto removido."
    rm -f "$ARQUIVO"
    exit 5
fi

# ---------- 3. o arquivo ficou bom? ----------
if ! gzip -t "$ARQUIVO" 2>/dev/null; then
    log ERRO "O arquivo $ARQUIVO está corrompido. Removendo."
    rm -f "$ARQUIVO"
    exit 6
fi

TABELAS=$(gzip -dc "$ARQUIVO" | grep -c '^CREATE TABLE')
TAMANHO=$(du -h "$ARQUIVO" | cut -f1)
log OK "Backup criado: $(basename "$ARQUIVO") ($TAMANHO, $TABELAS tabelas)"

# ---------- 4. rotação: apaga os mais antigos ----------
REMOVIDOS=0
while IFS= read -r antigo; do
    rm -f "$antigo" && REMOVIDOS=$((REMOVIDOS + 1))
done < <(find "$DESTINO" -maxdepth 1 -name "${DB_NAME}_*.sql.gz" -type f | sort -r | tail -n +$((MANTER + 1)))

TOTAL=$(find "$DESTINO" -maxdepth 1 -name "${DB_NAME}_*.sql.gz" -type f | wc -l)
OCUPADO=$(du -sh "$DESTINO" | cut -f1)
log INFO "Rotação: $REMOVIDOS antigo(s) removido(s). Backups guardados: $TOTAL. Espaço usado: $OCUPADO"

exit 0
