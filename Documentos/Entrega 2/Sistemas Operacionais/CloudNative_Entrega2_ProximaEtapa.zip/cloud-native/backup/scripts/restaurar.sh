#!/bin/bash
# =============================================================================
# restaurar.sh - Restaura um backup do banco do app Próxima Etapa
#
# Uso:
#   restaurar.sh               restaura o backup mais recente
#   restaurar.sh arquivo.sql.gz restaura um backup específico da pasta /backups
# =============================================================================

set -o pipefail
[ -f /app/ambiente.sh ] && . /app/ambiente.sh

DESTINO="/backups"
LOG="$DESTINO/logs/backup.log"
mkdir -p "$DESTINO/logs"

log() { local l; l="[$(date '+%Y-%m-%d %H:%M:%S')] [$1] $2"; echo "$l"; echo "$l" >> "$LOG"; }

if [ -n "$1" ]; then
    ARQUIVO="$DESTINO/$(basename "$1")"
else
    ARQUIVO=$(find "$DESTINO" -maxdepth 1 -name "${DB_NAME}_*.sql.gz" -type f | sort -r | head -n 1)
fi

if [ -z "$ARQUIVO" ] || [ ! -f "$ARQUIVO" ]; then
    log ERRO "Nenhum backup encontrado para restaurar (${1:-mais recente})."
    exit 1
fi

if ! gzip -t "$ARQUIVO" 2>/dev/null; then
    log ERRO "O arquivo $(basename "$ARQUIVO") está corrompido. Restauração cancelada."
    exit 2
fi

export MYSQL_PWD="$DB_ROOT_PASSWORD"
CLIENTE=$(command -v mariadb || command -v mysql)

log INFO "Restaurando $(basename "$ARQUIVO") no banco '$DB_NAME'..."
if gzip -dc "$ARQUIVO" | "$CLIENTE" --host="$DB_HOST" --user=root; then
    log OK "Restauração concluída."
else
    log ERRO "Falha na restauração."
    exit 3
fi
