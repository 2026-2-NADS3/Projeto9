#!/bin/bash
# Inicializa o container de backup: confere a configuração, agenda o backup no
# cron e deixa o crond rodando em primeiro plano (processo principal do container).
set -e

for variavel in DB_HOST DB_NAME DB_ROOT_PASSWORD BACKUP_CRON; do
    if [ -z "${!variavel}" ]; then
        echo "[entrypoint] ERRO: variável $variavel não definida. Confira o arquivo .env." >&2
        exit 1
    fi
done

# O cron não herda as variáveis do container; por isso elas vão para um arquivo
# que só o root consegue ler e que o backup.sh carrega.
{
    for variavel in DB_HOST DB_NAME DB_ROOT_PASSWORD BACKUP_MANTER TZ; do
        printf 'export %s=%q\n' "$variavel" "${!variavel}"
    done
} > /app/ambiente.sh
chmod 600 /app/ambiente.sh

# Agenda: a saída vai para o log do container (docker compose logs backup)
echo "$BACKUP_CRON /app/backup.sh > /proc/1/fd/1 2>&1" > /etc/crontabs/root
echo "[entrypoint] Backup agendado: '$BACKUP_CRON' (mantendo ${BACKUP_MANTER:-7} cópias)"

# Primeiro backup logo ao subir, para já ter uma cópia
if [ "${BACKUP_AO_INICIAR:-true}" = "true" ]; then
    /app/backup.sh || echo "[entrypoint] AVISO: o primeiro backup falhou; o cron tenta de novo no próximo horário."
fi

exec crond -f -l 8
