<?php
// Verifica se a API está no ar e se consegue falar com o banco.
// Usado no teste do ambiente Docker: http://localhost:8080/proxima_etapa_api/status.php
require 'config.php';

$cursos = consultar($conn, "SELECT COUNT(*) AS total FROM cursos");

responder([
    "success" => true,
    "status" => "ok",
    "banco" => getenv('DB_HOST') ?: 'localhost',
    "cursos" => $cursos[0]['total'] ?? 0,
    "hora" => date('Y-m-d H:i:s')
]);
